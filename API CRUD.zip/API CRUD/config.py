
# Configuraciones globales (si las necesitas)
