
# app/main.py
from fastapi import FastAPI
from app.routes import item_router, user_router

app = FastAPI(title="My FastAPI Project", description="API RESTful con FastAPI y MongoDB")

app.include_router(item_router)
app.include_router(user_router)

@app.get("/")
async def root():
    return {"message": "Bienvenido a la API"}
