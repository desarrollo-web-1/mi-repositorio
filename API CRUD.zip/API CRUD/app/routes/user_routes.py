# app/routes/user_routes.py
from fastapi import APIRouter, HTTPException
from app.schemas import User
from app.services.user_service import UserService 
from typing import List

router = APIRouter(prefix="/users", tags=["users"])

@router.post("/", response_model=User, status_code=201)
async def create_user(user: User):
    return UserService.create_user(user)

@router.get("/", response_model=List[User])
async def get_all_users():
    return UserService.get_all_users()

@router.get("/{id}", response_model=User)
async def get_user(id: str):
    user = UserService.get_user_by_id(id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return user

@router.put("/{id}", response_model=User)
async def update_user(id: str, user: User):
    updated_user = UserService.update_user(id, user)
    if not updated_user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return updated_user

@router.delete("/{id}", status_code=204)
async def delete_user(id: str):
    if not UserService.delete_user(id):
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return None