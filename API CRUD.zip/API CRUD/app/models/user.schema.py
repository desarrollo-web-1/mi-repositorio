# app/schemas/user_schema.py
from app.models.user_model import User
