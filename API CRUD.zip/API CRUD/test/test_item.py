from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_item():
    response = client.post("/items/", json={"name": "Test Item", "description": "Test Desc", "price": 10.5})
    assert response.status_code == 201
    assert response.json()["name"] == "Test Item"
    