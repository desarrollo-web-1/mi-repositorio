# tests/__init__.py
# Puede estar vacío
